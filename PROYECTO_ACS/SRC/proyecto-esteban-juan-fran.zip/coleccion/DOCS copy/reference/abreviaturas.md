#

* abrebiatura proyecto
    Administración de Centros de Salud: ACS

* Abreviatura Tablas
    nombre tabla: ACS_nombre_tabla
    identificador tabla: A(2 iniciales nombre tabla)
    atributo: (identificador tabla)_nombre_Atributo

* Abreaviarura nombres
    TRIGGER: TRG
    function: FUN
    procedure: PRC
    package: PKG
    JOB: JOB

* ABREVIATURA en procesos
     CHECK(revisar): CHK
     V_= VARIABLE. para asignar valores
     R_ = RECORD. para recorrer cursores
     C_ = CURSOR. para definir una consulta a la cual se va a recorrer
